# Agents

This directory will contain production-ready AI agents.

- Place agent implementations here, e.g. `sequential-thinking/`, `dev-agent/`, etc.
- Each agent should export an async `run()` entry-point. 
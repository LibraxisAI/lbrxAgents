# Memory Layer

This folder will host memory-related helpers:

- **memory-api.js** – high-level wrapper over MCP memory server.
- **context-manager.js** – manage project context windows.
- Vector store adapters, snapshot utilities, etc. 
# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build/Lint/Test Commands
- **Run tests**: `npm test` (runs tests/test-a2a.js)
- **Run single test**: `node tests/test-a2a.js` or other specific test file
- **Security scanning**: `npm run semgrep:scan`
- **Monitor file changes**: `npm run tree:monitor`
- **Initialize an agent**: `node scripts/initialize-agent.js AgentName "Description" "capability1,capability2"`

## Code Style Guidelines
- **Formatting**: Use editor's formatOnSave with standard JS conventions
- **Imports**: Group by type (core Node modules → third-party → local packages)
- **Error Handling**: Use try/catch with specific error types
- **Naming**: camelCase for variables/functions, PascalCase for classes
- **UUIDs**: Generate dynamically, avoid hardcoded values
- **Paths**: Use standardized base paths with `agentApi.setBasePath()`
- **File Structure**: Follow established protocol directory structure
- **Commit Format**: Include `(c)2025 M&K` in commit messages
- **Documentation**: Add footer with Claude Code and MCP Tools attribution

## Essential Project Context
lbrxAgents implements the Agent-to-Agent (A2A) protocol for multi-agent communication using a file-based messaging system. Key components include discovery, messaging, and orchestration capabilities.
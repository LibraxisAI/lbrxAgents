# Ratatui-termwiz

<!-- cargo-rdme start -->

This module provides the [`TermwizBackend`] implementation for the [`Backend`] trait. It uses
the [Termwiz] crate to interact with the terminal.

[`Backend`]: trait.Backend.html
[Termwiz]: https://crates.io/crates/termwiz

<!-- cargo-rdme end -->

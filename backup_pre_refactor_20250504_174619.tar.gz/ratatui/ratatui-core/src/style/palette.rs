#![allow(clippy::unreadable_literal)]

//! A module for defining color palettes.

pub mod material;
pub mod tailwind;

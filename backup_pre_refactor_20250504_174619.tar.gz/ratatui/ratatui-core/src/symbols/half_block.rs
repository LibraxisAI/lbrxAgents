pub const UPPER: char = '▀';
pub const LOWER: char = '▄';
pub const FULL: char = '█';

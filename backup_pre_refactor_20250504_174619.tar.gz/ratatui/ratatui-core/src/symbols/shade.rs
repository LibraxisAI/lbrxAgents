pub const EMPTY: &str = " ";
pub const LIGHT: &str = "░";
pub const MEDIUM: &str = "▒";
pub const DARK: &str = "▓";
pub const FULL: &str = "█";

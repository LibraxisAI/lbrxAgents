# xtask for ratatui

<!-- cargo-rdme start -->

A simple task runner for the project.

See <https://github.com/matklad/cargo-xtask> for details on the xtask pattern.

Run `cargo xtask --help` for more information

<!-- cargo-rdme end -->

# Security Policy

## Supported Versions

We only support the latest version of this crate.

## Reporting a Vulnerability

To report secuirity vulnerability, please use the form at <https://github.com/ratatui/ratatui/security/advisories/new>

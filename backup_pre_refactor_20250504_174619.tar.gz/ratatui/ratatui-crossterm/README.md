# Ratatui-crossterm

<!-- cargo-rdme start -->

This module provides the [`CrosstermBackend`] implementation for the [`Backend`] trait. It uses
the [Crossterm] crate to interact with the terminal.

[Crossterm]: https://crates.io/crates/crossterm

<!-- cargo-rdme end -->

# Gauge demo

This example shows different types of gauges.

To run this demo:

```shell
cargo run -p gauge
```

# Weather demo

This example shows how to render weather data using barchart widget.

To run this demo:

```shell
cargo run -p weather
```

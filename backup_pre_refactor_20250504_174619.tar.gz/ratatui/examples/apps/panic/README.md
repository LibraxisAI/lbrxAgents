# Panic demo

This example shows how to handle panics in your application.

To run this demo:

```shell
cargo run -p panic
```

# Todo list demo

This example demonstrates a simple todo list application.

To run this demo:

```shell
cargo run -p todo-list
```

# Flex demo

This interactive example shows how to use the flex layouts.

To run this demo:

```shell
cargo run -p flex
```

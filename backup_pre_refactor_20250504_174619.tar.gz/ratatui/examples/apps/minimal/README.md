# Minimal demo

This example shows how to create a minimal application.

To run this demo:

```shell
cargo run -p minimal
```

# WidgetRef Container demo

This example shows how to use [`WidgetRef`](https://docs.rs/ratatui/latest/ratatui/widgets/trait.WidgetRef.html) to store widgets in a container.

To run this demo:

```shell
cargo run -p widget-ref-container
```

# Scrollbar demo

This example shows how to render different types of scrollbars.

To run this demo:

```shell
cargo run -p scrollbar
```

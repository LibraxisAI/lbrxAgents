# Popup demo

This example shows how to handle popups.

To run this demo:

```shell
cargo run -p popup
```

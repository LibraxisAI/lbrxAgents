# User input demo

This example shows how to handle user input.

To run this demo:

```shell
cargo run -p user-input
```

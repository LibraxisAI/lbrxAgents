# Constraints demo

This example shows different types of constraints.

To run this demo:

```shell
cargo run -p constraints
```

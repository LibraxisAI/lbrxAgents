# Hyperlink demo

This example shows how to render hyperlinks in a terminal using [OSC 8](https://gist.github.com/egmontkob/eb114294efbcd5adb1944c9f3cb5feda).

To run this demo:

```shell
cargo run -p hyperlink
```

# Inline demo

This example shows how to use the inlined viewport to render in a specific area of the screen.

To run this demo:

```shell
cargo run -p inline
```

# Custom widget demo

This example shows how to create a custom widget that can be interacted with the mouse.

To run this demo:

```shell
cargo run -p custom-widget
```

# Hello World demo

This example shows how to create a simple TUI with a text.

To run this demo:

```shell
cargo run -p hello-world
```

# Calendar explorer demo

This example shows how to render a calendar with different styles.

To run this demo:

```shell
cargo run -p calendar-explorer
```

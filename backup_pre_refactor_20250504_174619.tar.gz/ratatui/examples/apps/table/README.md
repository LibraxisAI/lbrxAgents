# Table demo

This example shows how to create an interactive table.

To run this demo:

```shell
cargo run -p table
```

# Advanced Widget Implementation demo

This example shows how to render the `Widget` trait in different ways.

To run this demo:

```shell
cargo run -p advanced-widget-impl
```

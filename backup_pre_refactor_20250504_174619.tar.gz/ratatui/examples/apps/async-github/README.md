# Async GitHub demo

This example demonstrates how to use Ratatui with widgets that fetch data from GitHub API asynchronously.

To run this demo:

```shell
cargo run -p async-github
```

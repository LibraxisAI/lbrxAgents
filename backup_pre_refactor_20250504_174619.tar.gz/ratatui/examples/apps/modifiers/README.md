# Modifiers demo

This example shows different types of modifiers.

To run this demo:

```shell
cargo run -p modifiers
```

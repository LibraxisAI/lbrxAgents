# Canvas demo

This example shows how to render various shapes and a map on a canvas.

To run this demo:

```shell
cargo run -p canvas
```

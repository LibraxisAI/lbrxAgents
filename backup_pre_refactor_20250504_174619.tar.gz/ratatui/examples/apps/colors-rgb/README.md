# Colors-RGB demo

This example shows the full range of RGB colors in an animation.

To run this demo:

```shell
cargo run -p colors-rgb
```

# Tracing demo

This example demonstrates how to use the [tracing](https://crates.io/crates/tracing) crate to log to a file.

To run this demo:

```shell
cargo run -p tracing
```

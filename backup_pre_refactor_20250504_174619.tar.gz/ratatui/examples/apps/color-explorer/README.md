# Color explorer demo

This example shows how to handle the supported colors.

To run this demo:

```shell
cargo run -p color-explorer
```

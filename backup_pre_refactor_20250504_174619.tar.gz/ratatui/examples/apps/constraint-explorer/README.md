# Constraint explorer demo

This interactive example shows how different constraints can be used to layout widgets.

To run this demo:

```shell
cargo run -p constraint-explorer
```

# Mouse drawing demo

This example shows how to receive mouse and handle mouse events.

To run this demo:

```shell
cargo run -p mouse-drawing
```

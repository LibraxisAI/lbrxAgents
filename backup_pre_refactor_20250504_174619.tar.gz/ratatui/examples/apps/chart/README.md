# Chart demo

This example shows how to render line, bar, and scatter charts.

To run this demo:

```shell
cargo run -p chart
```

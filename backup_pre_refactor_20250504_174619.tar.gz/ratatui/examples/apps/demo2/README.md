## Demo2

This is the demo example from the main README and crate page. Source: [demo2](./demo2/).

```shell
cargo run -p demo2
```

![Demo2](https://github.com/ratatui/ratatui/blob/images/examples/demo2.gif?raw=true)

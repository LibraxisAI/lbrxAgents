# CHANGELOG


## v0.1.0 (2024-12-27)

### Chores

- Update gitignore
  ([`97ba25c`](https://github.com/doobidoo/mcp-memory-service/commit/97ba25c83113ed228d6684b8c65bc65774c0b704))

### Features

- Add MCP protocol compliance and fix response formats
  ([`fefd579`](https://github.com/doobidoo/mcp-memory-service/commit/fefd5796b3fb758023bb574b508940a651e48ad5))

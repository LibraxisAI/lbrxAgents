#[derive(Debug, Clone)]
pub enum Action {
    RefreshAgents,
    SelectNext,
    SelectPrev,
    TogglePanel,
} 